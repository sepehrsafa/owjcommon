from tortoise.models import Model
from typing import Type, List

async def get_paginated_results(model: Type[Model], offset: int, size: int, prefetch_related = None) -> dict:
    total_items = await model.all().count()
    total_pages = (total_items - 1) // size + 1
    if prefetch_related is None:
        items = await model.all().offset(offset).limit(size)
    else:
        items = await model.all().prefetch_related(*prefetch_related).offset(offset).limit(size)

    return {"total_pages": total_pages, "items": items}


async def get_paginated_data_results(data, offset: int, size: int) -> dict:
    total_items = len(data)
    total_pages = (total_items - 1) // size + 1
    
    #calculate offset and limit
    offset = offset * size
    limit = offset + size

    #check if offset is greater than total items
    if offset > total_items:
        offset = total_items

    #check if limit is greater than total items
    if limit > total_items:
        limit = total_items

    items = data[offset:limit]


    return {"total_pages": total_pages, "items": items}
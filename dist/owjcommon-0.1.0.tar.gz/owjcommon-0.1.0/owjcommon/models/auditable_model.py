from tortoise.models import Model
from tortoise import fields
import uuid
from ..exceptions import OWJException
from ..enums import AuditTypeEnum


class AuditableModel(Model):
    audit_log_class: Model = None

    id = fields.IntField(pk=True)
    uuid = fields.UUIDField(default=uuid.uuid4, unique=True, index=True)

    class Meta:
        abstract = True

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if cls.audit_log_class is None:
            raise TypeError(
                "Subclasses of AuditableModel must provide an audit_log_class."
            )

    async def log_changes(self, instance, model_pk, type, changes, user=None):
        # check user type if string or object
        if user:
            if isinstance(user, str):
                user = user
            else:
                user = user.uuid

        audit_log = self.audit_log_class()
        await audit_log.create(
            model_name=instance.__class__.__name__,
            model_pk=model_pk,
            type=type,
            changes=changes,
            changed_by_id=user,
        )

    async def save(self, *args, user=None, **kwargs):
        changes = {}
        new_instance = False

        original_instance = await type(self).get_or_none(pk=self.pk)
        if original_instance:
            for field in self._meta.fields_map.keys():
                original_value = getattr(original_instance, field)
                current_value = getattr(self, field)
                if original_value != current_value:
                    changes[field] = {
                        "old": str(original_value),
                        "new": str(current_value),
                    }
        else:
            new_instance = True
            for field in self._meta.fields_map.keys():
                current_value = getattr(self, field)
                changes[field] = {"old": None, "new": str(current_value)}

        await super().save(*args, **kwargs)
        if changes and new_instance:
            await self.log_changes(
                self, self.pk, AuditTypeEnum.CREATE, changes, user=user
            )
        elif changes:
            await self.log_changes(
                self, self.pk, AuditTypeEnum.UPDATE, changes, user=user
            )

    async def get_or_exception(self, *args, **kwargs):
        data = await self.get_or_none(*args, **kwargs)
        if data is None:
            raise OWJException("E1023", 404)

from enum import Enum


class CurrencyChoices(str, Enum):
    IRR = "IRR"

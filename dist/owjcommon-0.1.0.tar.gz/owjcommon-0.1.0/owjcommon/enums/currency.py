from enum import Enum


class CurrencyChoices(str, Enum):
    USD = "USD"
    CAD = "CAD"
    IRR = "IRR"
    IRT = "IRT"
